Designed and developed by Avinash Pawar cloudmail.project.x@gmail.com
liacenced as open source 
code on my github https://github.com/ProjectX-v0 




To add your own questions make changes in question.json

and dont forget to edit game.js file for toatl questions and their marks.